var baseUrl = `${window.location.origin}`;

$(document).ready(function () {


  /*Sticky_Header */
      $(window).scroll(function () {
          var scroll = $(window).scrollTop();

          if (scroll >= 10) {
              $(".main-header").addClass("sticky");
          } else {
              $(".main-header").removeClass("sticky");
          }
      });


      /*menu-slidetoggle */
      $(".menu-toggle").click(function () {
        $(".full-menu").toggleClass("slide-right");
        $(this).find('i').toggleClass('fa-bars fa-times')
    });

  //color-swatches-change on click
  $(function () {
    'use strict';
    $('.switch-color li').on('click', function () {
      $(':root').css('--color1', $(this).data('color'));
    });
  });
  //color-swatches slide out
  $(document).ready(function ($) {
    $('#slide-button, .close-icon').click(function () {
      $('.palette-swatches').toggleClass('show');
    });
  });


  // Increase/descrease font size

  var $affectedElements = $("*"); // Can be extended, ex. $("div, p, span.someClass")

  // Storing the original size in a data attribute so size can be reset
  $affectedElements.each( function(){
    var $this = $(this);
    $this.data("orig-size", $this.css("font-size") );
  });

  $("#btn-increase").click(function(){
    changeFontSize(1);
  })

  $("#btn-decrease").click(function(){
    changeFontSize(-1);
  })

  $("#btn-orig").click(function(){
    $affectedElements.each( function(){
          var $this = $(this);
          $this.css( "font-size" , $this.data("orig-size") );
     });
  })

  function changeFontSize(direction){
      $affectedElements.each( function(){
          var $this = $(this);
          $this.css( "font-size" , parseInt($this.css("font-size"))+direction );
      });
  }


  });
  $(document).ready(function(){
    $(".user-sec").click(function(){
      $(".user-box").slideToggle("slow");
    });

    $(".menu-toggle").click(function () {
      $(".menu-res").slideToggle();
      $(this).find('i').toggleClass('fa-bars fa-times')
  });
  });




  //Total Meters Count- Chart Home page
  $('.total-meter_btn').click(function() {

    let fromDate = $('#from_date').val();
    let toDate = $('#to_date').val();

            // Get session ID from local storage
        const sessionId = localStorage.getItem("sessionId"); // Adjust key name if needed

        if (sessionId) {
            console.log("Constructed URL:", url);
        // You can now use this URL for your API call, e.g., using fetch or axios
        } else {
            console.error("Session ID not found in localStorage.");
        }

        let requestUrl = `${baseUrl}"/api/gas/pfdb_commissioned_data?from_date=${fromDate}&to_date=${toDate}"`;

    $.ajax({

        url: requestUrl,
        method: "GET",
        headers: {
          "sessionId": "f72c970e-792b-40f7-954a-a82958d20cb5-57"
        },
        success: function (response) {

            const dataValues = [
                parseInt(response.commissionedMeters),
                parseInt(response.nonCommissionedMeters)
            ];
            const dataLabels = ["Commissioned", "Non-Commissioned"];
            const colors = ["#55A605", "#D83535"];
            updateChart(dataValues, dataLabels, colors, parseInt(response.totalMeters));


            //----------------------------
            const commisionedResources = response.commissionedMetersResources;
            const noncommisionedResources = response.nonCommissionedMetersResources;

            console.log(commisionedResources);

            console.log(noncommisionedResources);


            const tableBody = document.getElementById("comm_data");

            let Count=1;
            let bp_no=2333;

            // Iterate through the data and create table rows
            commisionedResources.forEach(item => {
                const row = document.createElement("tr"); // Create a new row

                // Create and append cells to the row
                row.innerHTML = `
                  <th scope="row">${Count++}</th>
                  <td>${item.serial_no || "-"}</td>
                  <td>${item.contract_ac_no || "-"}</td>
                  <td>${item.unit_name || "-"}</td>
                  <td>${item.subscriber_name || "-"}</td>
                  <td>${item.subscriber_no || "-"}</td>
                  <td>${item.meter_non_commissioned_date ? new Date(item.meter_non_commissioned_date).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }) : "-"}</td>
                  <td>${item.meter_in_service_date ? new Date(item.meter_in_service_date).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }) : "-"}</td>
                  <td>${item.model_name || "-"}</td>
                `;

                // Append the row to the table body
                tableBody.appendChild(row);
              });


            const tableBody_ncom = document.getElementById("non_comm_data");

            Count=1;
            bp_no=2333;

            // Iterate through the data and create table rows
            noncommisionedResources.forEach(item => {
                const row = document.createElement("tr"); // Create a new row

                // Create and append cells to the row
                row.innerHTML = `
                  <th scope="row">${Count++}</th>
                  <td>${item.serial_no || "-"}</td>
                  <td>${item.contract_ac_no || "-"}</td>
                  <td>${item.unit_name || "-"}</td>
                  <td>${item.subscriber_name || "-"}</td>
                  <td>${item.subscriber_no || "-"}</td>
                  <td>${item.meter_non_commissioned_date ? new Date(item.meter_non_commissioned_date).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }) : "-"}</td>
                  <td>${item.meter_in_service_date ? new Date(item.meter_in_service_date).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }) : "-"}</td>
                  <td>${item.model_name || "-"}</td>
                `;

                // Append the row to the table body
                tableBody_ncom.appendChild(row);
              });

            //-------------------------
        },
        error: function (error) {
            console.error("Error fetching chart data:", error);
        }
        
    });
  });

  function updateChart(dataValues, dataLabels, colors, totalCount) {
    var BAChartCtx = document.getElementById('BA-chart-job-error').getContext('2d');
    var BAChartJobErr = new Chart(BAChartCtx, {
      type: 'doughnut',
      data: {
        labels:  dataLabels,
        datasets: [{
          data: dataValues,
          backgroundColor: colors,
          borderColor: '#fff',
          borderWidth: 6,
        }]
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        title: {
          display: true,
          position: 'center',
          fontSize: 28,
          fontColor: '#767676',
              fontFamily:'Plus Jakarta Sans',
          fontStyle: '600',
          padding: 44,
          margin: 30,
          // text: 'Total Meters',
        },
        legend: {
          display: true,
          position: 'top',
          "labels": {
            "fontSize": 16,
            "fontFamily" : 'Plus Jakarta Sans',
             "fontWeight": '700',
          }
        },
        plugins: {
          labels: [
            {
              render: 'label',
              fontColor: 'transparent',
                    fontSize: 24,
                    fontStyle: '600',
                padding: 44,
                    margin:10,
                    fontFamily:'Plus Jakarta Sans',
              position: 'outside'
            },
            {
              render: 'value',
              fontColor: '#fff',
                    fontSize: 24,
                    fontStyle: '600',
                    fontFamily:'Plus Jakarta Sans',
            }
          ],
          doughnutlabel: {
            labels: [
              {
                text: totalCount,
                color:'#000',
                font: {
                  size: 40,
                  weight:600,
                  family:'Plus Jakarta Sans',
                }

              }
            ]
          }
        }
      }
    });
  }

  window.addEventListener('load', fetchChartData);



  //Alarms / Events

  $('.battery-btn').click(function() {
    const batteryData = $(this).data('battery'); // Get the battery data from 'this'

    // Store batteryData in a variable
    const batteryType = batteryData; // Store it in a variable

    // Arrow function with the external data
    (() => {
        const apiUrl = `${baseUrl}/api/gas/pfdb_alarms_and_events_data?from_date=2024-10-01&to_date=2024-12-03&type=${encodeURIComponent(batteryType)}`;

        console.log(apiUrl);

            $.ajax({
              url: apiUrl,
              type: 'GET',
              headers: {
                "sessionId": "f72c970e-792b-40f7-954a-a82958d20cb5-57"
              },
              success: function(response) {
                console.log('Server Response:', response);
                $('#response').text(`Server says: ${response.message}`);


                const resource = response.dataMapList;

                // Get the corresponding tbody element
          const tableBody = document.getElementById(batteryType);

          tableBody.innerHTML = "";

          // Populate the table with data
          if (tableBody) {
              let count = 1;

              resource.forEach(item => {
                  const row = document.createElement("tr"); // Create a new row

                  // Create and append cells to the row
                  row.innerHTML = `
                    <th></th>
                    <th scope="row">${count++}</th>
                    <td>${item.LDN || "-"}</td>
                    <td>${item.BPNO || "-"}</td>
                    <td>${item.LDP ? new Date(item.LDP).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }) : "-"}</td>
                    <td>${item.eventCode || "-"}</td>
                    <td>${item.batteryPercentage || "-"}</td>
                    <td>${item.reading || "-"}</td>
                  `;

                  // Append the row to the table body
                  tableBody.appendChild(row);
              });
          } else {
              console.error("Invalid type or tbody ID not found for type:", type);
          }

              },
              error: function(error) {
                console.error('Error occurred:', error);
              }
            });

          })();
        });

  //===========================================================================================================//
  //===========================================================================================================//


    //Communicating Status Section

  $('.comm_status-btn').click(function (event) {
    event.preventDefault(); // Prevent form reload

    let comunicatingData = $(this).data('comm_status');
    let fromDate = $('#from_date').val();
    let toDate = $('#to_date').val();


    if (fromDate.length === 0 || fromDate === null)
      fromDate = "";

    if (toDate.length === 0 || toDate === null)
      toDate = "";

    console.log("hello world skvfskvuf  ");

    // if (!fromDate || !toDate) {
    //   alert("Please select both From Date and To Date.");
    //   return;
    // }

    const apiCommUrl = `${baseUrl}/api/gas/pfdb_communication_status_data?from_date=${fromDate}&to_date=${toDate}`;




    console.log("API URL:", apiCommUrl);

    $.ajax({
      url: apiCommUrl,
      type: 'GET',
      headers: { "sessionId": "f72c970e-792b-40f7-954a-a82958d20cb5-57" },
      success: function (response) {
        console.log("Full API Response:", response);

        const categories = Array.isArray(response.dateList) ? response.dateList : [];
        const seriesData = [
          { name: 'Communicating Meters', data: categories.map(date => response[date]?.communicatingMeters || 0) },
          { name: 'Non-Communicating Meters', data: categories.map(date => response[date]?.nonCommunicatingMeters || 0) }
        ];

        if (categories.length > 0 && seriesData.some(series => series.data.length > 0)) {
          updateCommChart(categories, seriesData);
          populateCommunicationTable(response);
          populateDynamicLinks(response.totalPages,"abc");
    
        } else {
          $('#response').text("No valid data available for the chart.");
        }
      



// Select the <ul> element
// const paginationUl = document.getElementById("commPagination");

// // Clear all existing <li> elements except the first and last
// const firstLi = paginationUl.firstElementChild;
// const lastLi = paginationUl.lastElementChild;
// paginationUl.innerHTML = ""; // Clear all content
// paginationUl.appendChild(firstLi); // Add the first <li> back

// // Assuming response.totalPages is available and valid
// const totalPages = response.totalPages; // Example: Total number of pages
// console.log("Total Pages:", totalPages); // Debugging log

// // Variables to track pagination
// let currentStartPage = 1;
// const pagesPerGroup = 10; // Number of pages to show per group

// // Function to render pagination for the current group
// function renderPagination(startPage) {
//     paginationUl.innerHTML = ""; // Clear existing pagination
//     paginationUl.appendChild(firstLi); // Add the first <li> back

//     const endPage = Math.min(startPage + pagesPerGroup - 1, totalPages);

//     for (let i = startPage; i <= endPage; i++) {
//         let li = document.createElement("li");
//         li.className = `page-item comm_status-btn ${i === currentStartPage ? 'active' : ''}`; // Highlight the active page
//         li.setAttribute("data-name", i);

//         let anchor = document.createElement("a");
//         anchor.className = "page-link";
//         anchor.href = "#";
//         anchor.textContent = i;

//         anchor.addEventListener("click", (event) => {
//             event.preventDefault();
//             document.querySelectorAll(".page-item").forEach(item => item.classList.remove("active"));
//             li.classList.add("active"); // Highlight the clicked page
//             console.log("Page clicked:", i); // Debugging log
//             fetchPageData(i); // Call the API for the selected page
//         });

//         li.appendChild(anchor);
//         paginationUl.appendChild(li);
//     }

//     paginationUl.appendChild(lastLi); // Add the last <li> back

//     // Enable or disable navigation arrows
//     firstLi.classList.toggle("disabled", startPage === 1);
//     lastLi.classList.toggle("disabled", endPage === totalPages);
// }

// // Add click event listeners to the first and last <li> for navigation
// firstLi.addEventListener("click", () => {
//     if (currentStartPage > 1) {
//         currentStartPage = Math.max(1, currentStartPage - pagesPerGroup);
//         renderPagination(currentStartPage);
//     }
// });

// lastLi.addEventListener("click", () => {
//     if (currentStartPage + pagesPerGroup <= totalPages) {
//         currentStartPage = Math.min(totalPages - pagesPerGroup + 1, currentStartPage + pagesPerGroup);
//         renderPagination(currentStartPage);
//     }
// });

// // Render the initial pagination
// renderPagination(currentStartPage);

// // Mock fetchPageData function for testing
// function fetchPageData(page) {
//   console.log(`Fetching data for page ${page}`);
// }




        // ==========




      
        // const resourcesTable = $('#resources-table > tbody');
        // resourcesTable.empty();
        // if (response.resources && response.resources.length > 0) {
        //   response.resources.forEach(resource => {
        //     const row =
        //     `<tr>
        //         <td></td>
        //         <td></td>
        //         <td>${resource.appliance_serial_no || "-"}</td>
        //         <td>${resource.contract_ac_no || "-"}</td>
        //         <td>${resource.unit_name || "-"}</td>
        //         <td>${resource.subscriber_no || "-"}</td>
        //         <td>${resource.appliance_name || "-"}</td>
        //         <td>${resource.closing_reading || "-"}</td>
        //         <td>${resource.reason || "-"}</td>
        //         <td>${resource.last_update_time ? new Date(resource.last_update_time).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }) : "-"}</td>
        //         <td>${resource.signal_strength || "-"}</td>
        //         <td>${resource.battery_strength || "-"}</td>
        //         <td>${resource.signal_quality_strength || "-"}</td>
        //         <td>${resource.rsrp || "-"}</td>
        //         <td>${resource.signal_noise || "-"}</td>
        //         <td>${resource.frequency || "-"}</td>
        //         <td>${resource.cell_tower_id || "-"}</td>
        //         <td>${resource.ecl || "-"}</td>
        //     </tr>`;
        //     resourcesTable.append(row);
        //   });
        // } else {
        //   console.error("No resources data available.");
        // }
  
        $('#response').text("Chart and table updated successfully!");
      },
      error: function (xhr, status, error) {
        console.error('Error:', error);
        $('#response').text("Failed to fetch data from the server.");
      }

     
    });
  });


  function populateCommunicationTable(response) {
    // Select the table body where rows will be appended
    const resourcesTable = document.querySelector("#resourcesTable tbody");

    // Clear existing rows from the table body
    resourcesTable.innerHTML = "";

    // Iterate over each resource in the response and create a row
    response.resources.forEach(resource => {
        // Create a table row using template literals
        const row = `
            <tr>
                <td></td>
                <td></td>
                <td>${resource.appliance_serial_no || "N/A"}</td>
                <td>${resource.contract_ac_no || "N/A"}</td>
                <td>${resource.unit_name || "N/A"}</td>
                <td>${resource.subscriber_no || "N/A"}</td>
                <td>${resource.appliance_name || "N/A"}</td>
                <td>${resource.closing_reading || "N/A"}</td>
                <td>${resource.reason || "N/A"}</td>
                <td>${resource.last_update_time ? new Date(resource.last_update_time).toLocaleString("en-GB", { 
                    day: "2-digit", 
                    month: "short", 
                    year: "numeric", 
                    hour: "2-digit", 
                    minute: "2-digit", 
                    second: "2-digit", 
                    hour12: false 
                }) : "N/A"}</td>
                <td>${resource.signal_strength || "N/A"}</td>
                <td>${resource.battery_strength || "N/A"}</td>
                <td>${resource.signal_quality_strength || "N/A"}</td>
                <td>${resource.rsrp || "N/A"}</td>
                <td>${resource.signal_noise || "N/A"}</td>
                <td>${resource.frequency || "N/A"}</td>
                <td>${resource.cell_tower_id || "N/A"}</td>
                <td>${resource.ecl || "N/A"}</td>
            </tr>`;

        // Append the row to the table body
        resourcesTable.insertAdjacentHTML("beforeend", row);
    });
}




  // Function to create and update the bar chart
  function updateCommChart(categories, data) {
  
    console.log(categories);
    console.log(data);
  
    const options = {
      series: data,
      chart: {
      type: 'bar',
      height: 350
      },
      colors:['#55A605', '#D83535'],
      font: {
        size: 40,
        weight:600,
        family:'Plus Jakarta Sans',
      },
      plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: '40%',
        columnGap:'20',
        endingShape: 'rounded'
      },
      },
      dataLabels: {
            formatter: (val) => val
          },
      stroke: {
      show: true,
      width: 2,
      colors: ['transparent']
      },
      xaxis: {
      categories: categories,
      },
      yaxis: {
      title: {
        text: 'Units',
        
      }
      },
      fill: {
      opacity: 1
      },
      tooltip: {
      y: {
        formatter: function (val) {
        return val 
        }
      }
      }
      };
    
    // Render or update the chart
    const chartContainer = document.querySelector("#tab-chart");
    chartContainer.innerHTML = ""; // Clear previous chart, if any
    const chart = new ApexCharts(chartContainer, options);
    chart.render();
  
  }
  
  window.addEventListener('load', () => {
    console.log("Page loaded. Add any default chart or functionality here.");
  });
  
  
  //===========================================================================================================//
  //===========================================================================================================//
  
  
  // Valve Status Section
  
  $('.valve_status-btn').click(function (event) {
    event.preventDefault(); // Prevent form reload
  
    let valvefromDate = $('#valvefrom_date').val();
    let valvetoDate = $('#valveto_date').val();
    let type = $(this).data('name'); // e.g., "NO_CONSUMPTION"
  
    if (type.length === 0 || type === null) 
      type = "NO_CONSUMPTION";
  
    // if (valvefromDate.length === 0 || valvefromDate === null) 
    //   valvefromDate = "";
  
    // if (valvetoDate.length === 0 || valvetoDate === null) 
    //   valvetoDate = "";
  
    if (!valvefromDate || !valvetoDate) {
      if (valvefromDate.length === 0 || valvefromDate === null) valvefromDate = "";
      if (valvetoDate.length === 0 || valvetoDate === null) valvetoDate = "";
        //   
    }
  
    else{
      if(new Date(valvefromDate) > new Date(valvetoDate)) {
        alert("From Date cannot be greater than To Date.");
        return;
    } 
    }  
      
    console.log("type------"+type);
  
    if(type==="ALARMS")type= "TILT";
    if(type==="BALANCE_ALERTS")type= "BALANCE_ALERTS_VALVE_CLOSED";
      
  
    // if (!valvefromDate || !valvetoDate) {
    //   alert("Please select both From Date and To Date.");
    //   return;
    // }
  
  
  
    const apiValveUrl = `${baseUrl}/api/gas/pfdb_valve_status_data?from_date=${valvefromDate}&to_date=${valvetoDate}&type=${type}`;
  
    console.log("API URL:", apiValveUrl);
  
    $.ajax({
      url: apiValveUrl,
      type: 'GET',
      headers: { "sessionId": "f72c970e-792b-40f7-954a-a82958d20cb5-57" },
      success: function (response) {
        console.log("Full API Response:", response);
  
        // Validate response structure
        if (!response || !response.dateList) {
          $('#response').text("Invalid response format or missing data.");
          console.log("Hello World");
          console.error("Invalid API response:", response);
          return;
        }
  


        function populateDynamicLinks(totalPages, type) {
          // Select the pagination <ul> element
          const paginationUl = document.getElementById("commPagination");
  
          // Preserve the "Previous" and "Next" buttons
          const firstLi = paginationUl.firstElementChild;
          const lastLi = paginationUl.lastElementChild;
          paginationUl.innerHTML = ""; // Clear current pagination
          paginationUl.appendChild(firstLi); // Add the "Previous" button
  
          // Dynamically create page links
          for (let i = 1; i <= totalPages; i++) {
              // Create a <li> element for each page
              const li = document.createElement("li");
             // li.className = `page-item ${i === 1 ? "active" : ""}`; // First page active by default
  
              // Create the anchor (<a>) element
              const anchor = document.createElement("a");
              anchor.href = "#"; // Placeholder href
              anchor.className = "page-link comm_status-btn"; // Use the 'comBut' class as requested
              anchor.textContent = i; // Page number as link text
              anchor.setAttribute("name", i); // Dynamically set the name attribute as the page number
              anchor.setAttribute("data-name", type); // Add a custom 'type' attribute for each link
  
              //  Add click event listener for the anchor
  //           anchor.addEventListener("click", (event) => {
  //               event.preventDefault(); // Prevent default anchor behavior
  //               // Update active class for pagination
  //              document.querySelectorAll(".page-item").forEach(item => item.classList.remove("active"));
  //                li.classList.add("active");
  //
  //                // Log details or call an API for the clicked page
  //               console.log(Page ${i} clicked, Type: ${type});
  //
  //                // Example: Call a data-fetching function
  //                fetchPageData(i, type);
  //            });
  //
  //            // Append the anchor to the <li>, and <li> to the <ul>
              li.appendChild(anchor);
              paginationUl.appendChild(li);
          }
  
          // Add the "Next" button back
          paginationUl.appendChild(lastLi);
      }
        
  
        // Populate table
        //populateTable(response.resources, type);
  
        const valveCategories = Array.isArray(response.dateList) ? response.dateList : [];
        console.log("Valve Categories:", valveCategories);
  
        const vseriesData = [
          {
            name: 'Total Valves',
            data: valveCategories.map(date => response[date]?.totalMeters || 0)
          },
          {
            name: 'Closed Valves',
            data: valveCategories.map(date => response[date]?.valveClosedMeters || 0)
          }
        ];
  
        console.log("Series Data:", vseriesData);
  
        if (valveCategories.length > 0 && vseriesData.some(series => series.data.some(value => value > 0))) {
          updateValveChart(valveCategories, vseriesData);
          $('#response').text("Chart and table updated successfully!");
        } else {
          $('#response').text("No valid data available for the chart.");
          console.warn("No data for the chart.");
        }
          console.log("Hello Word No communicstion-----"+ type);
         if(type==="NO_CONSUMPTION" || type==="NO_COMMUNICATIONS") populateConsumptionTable(response.dataMapList, type);
         if(type==="TILT" || type==="LEAK" || type ==="COVER_OPEN" || type==="UNAUTHORIZED_BATTERY_CHANGE") populateAlarmsTable(response.dataMapList, type);
         if(type==="BALANCE_ALERTS_VALVE_CLOSED" || type==="BALANCE_ALERTS_ABOUT_TO_CLOSE" || type==="BALANCE_ALERTS_NOTIFICATION_ISSUED" || type==="BALANCE_ALERTS_POSITIVE") populateBalanceAlertsTable(response.dataMapList,type);
         
      },
      
      error: function (xhr, status, error) {
        console.error(`Error: ${error}, Status: ${status}, Response:`, xhr.responseText);
        $('#response').text("Failed to fetch data from the server.");
    }
    
    });
  });

  function populateBalanceAlertsTable(resources,type) {
    // Get the table body element
    const tableBody = $('#' + type);

    console.log("Hello World !!!!" + type);
  
    // Clear any previous content in the table body
    tableBody.empty();
  
    // Loop through the data array and create rows
    resources.forEach((item, index) => {
      // Create a new table row
      const row = $('<tr></tr>');
  
      // Add cells to the row
      row.append('<td><input type="checkbox"></td>'); // Checkbox column
      row.append('<td>' + (index + 1) + '</td>'); // Serial Number
      row.append('<td>' + (item.appliance_serial_no || '-') + '</td>'); // LDN
      row.append('<td>' + (item.contract_ac_no || '-') + '</td>'); // BP No.
      row.append('<td>' + (item.unit_name || '-') + '</td>'); // Current Balance
      row.append('<td>' + (item.subscriber_no || '-') + '</td>'); // Current Balance
      row.append('<td>' + (item.appliance_name || '-') + '</td>'); // Current Balance
      row.append('<td>' + (item.closing_balance || '-') + '</td>'); // Current Balance
      row.append('<td>' + (item.last_update_time
        ? new Date(item.last_update_time).toLocaleString("en-GB", { 
            day: "2-digit", 
            month: "short", 
            year: "numeric", 
            hour: "2-digit", 
            minute: "2-digit", 
            second: "2-digit", 
            hour12: false 
        }) 
        : 'N/A') + '</td>');
  
      // Append the row to the table body
      tableBody.append(row);
    });
  }
  
  function populateAlarmsTable(resources,type){
    const tableBody = $('#' + type);
  
    console.log("Hello World====sssssstype---->"+type);
  
  // Clear any existing rows in the table body
    tableBody.empty();
  
  // Iterate over the resources and construct table rows
  resources.forEach((item, index) => {
  const row = $('<tr></tr>'); // Create a new row element
  
  // Add cells to the row
  row.append('<td><input type="checkbox"></td>'); // Checkbox column
  row.append('<td>' + (index + 1) + '</td>'); // Serial Number column
  row.append('<td>' + (item.LDN || 'N/A') + '</td>'); // LDN column
  row.append('<td>' + (item.BPNO || 'N/A') + '</td>'); // BP No. column
  row.append('<td>' + (item.unitName || 'N/A') + '</td>'); // Readings column
  row.append('<td>' + (item.subscriberName || 'N/A') + '</td>'); // Reason for Non-Communication column
  row.append('<td>' + (item.subscriberNo || 'N/A') + '</td>'); // LDN column
  row.append('<td>' + (item.eventCode || 'N/A') + '</td>'); // BP No. column
  row.append('<td>' + (item.eventTime
    ? new Date(item.eventTime).toLocaleString("en-GB", { 
        day: "2-digit", 
        month: "short", 
        year: "numeric", 
        hour: "2-digit", 
        minute: "2-digit", 
        second: "2-digit", 
        hour12: false 
    }) 
    : 'N/A') + '</td>');
  row.append('<td>' + (item.creationTime
    ? new Date(item.creationTime).toLocaleString("en-GB", { 
        day: "2-digit", 
        month: "short", 
        year: "numeric", 
        hour: "2-digit", 
        minute: "2-digit", 
        second: "2-digit", 
        hour12: false 
    }) 
    : 'N/A') + '</td>');
  row.append('<td>' + (item.reading || 'N/A') + '</td>'); // LDN column
  row.append('<td>' + (item.LDP
    ? new Date(item.LDP).toLocaleString("en-GB", { 
        day: "2-digit", 
        month: "short", 
        year: "numeric", 
        hour: "2-digit", 
        minute: "2-digit", 
        second: "2-digit", 
        hour12: false 
    }) 
    : 'N/A') + '</td>');

  
  // Append the row to the table body
  tableBody.append(row);
    });
  
      }
  
  function populateConsumptionTable(resources, type) {
    // Get the table body element by using the dataName (table id)
    const tableBody = $('#' + type );
    console.log("dataName====="+type);
    console.log("TableBody (HTML)----" + tableBody.html());
  
    // Clear any previous data in the table body
    tableBody.empty();
  
    // Loop through the resources and add rows to the table
    resources.forEach((item, index) => {
        const row = $(`
            <tr>
                <th scope="row"><input type="checkbox"></th>
                <td>${index + 1}</td> <!-- Serial number -->
                <td>${item.LDN}</td>
                <td>${item.BPNO}</td>
                <td>${item.subscriberName}</td>
                <td>${item.subscriberNo}</td>
                <td>${item.unitName}</td>
                <td>${item.reading}</td>
                <td>${item.currentBalance}</td>
                <td>${ new Date(item.LDP).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }) }</td>
                <td>${item.reason}</td>
                <td>
                  <div class="consump-date11">
                    <ul>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                    </ul>
                  </div>
                </td>
            </tr>
        `);
  
        // Append the row to the table body
    tableBody.append(row);
    });
  }
   
  
  function updateValveChart(valveCategories, vdata) {
    const chartContainer = document.querySelector("#valve-chart");
  
    if (!chartContainer) {
      console.error("Chart container not found!");
      return;
    }
  
    console.log("Chart Data:", vdata);
  
    // Clear previous chart
    if (chartContainer.chart) {
      chartContainer.chart.destroy();
    }
  
    if (!valveCategories.length || !vdata.some(series => series.data.length > 0)) {
      console.error("No valid data to render the chart.");
      return;
    }
  
    const options = {
      series: vdata,
      chart: {
        type: 'bar',
        height: 350,
        stacked: true
      },
      stroke: {
        width: 1,
        colors: ['#fff']
      },
      dataLabels: {
        formatter: val => (val !== undefined ? val : 0)
      },
      plotOptions: {
        bar: {
          horizontal: false
        }
      },
      xaxis: {
        categories: valveCategories
      },
      fill: {
        opacity: 1
      },
      colors: ['#55A605', '#F44336'],
      yaxis: {
        labels: {
          formatter: value => (value !== undefined ? value : 0)
        }
      },
      legend: {
        position: 'top',
        horizontalAlign: 'left'
      }
    };
  
    chartContainer.innerHTML = ""; // Clear any existing chart
    const chart = new ApexCharts(chartContainer, options);
    chart.render();
    chartContainer.chart = chart;
  
    console.log("Chart rendered successfully.");
  }
  
  window.addEventListener('load', () => {
    console.log("Page loaded. Add any default chart or functionality here.");
  });
  
  
   //===========================================================================================================//
  //===========================================================================================================//
  
  
  // Prepaid Status Section
  
  $('.prepaid-status-btn').click(function (event) {
    event.preventDefault(); // Prevent form reload
  
    let valvefromDate = "";
    let valvetoDate = "";
    let type = $(this).data('name');

    console.log("type------"+type);
  
    if (type.length === 0 || type === null) 
      type = "BALANCE_ALERTS_VALVE_CLOSED";
  
      
  
    // const apiValveUrl = ${baseUrl}/api/gas/pfdb_valve_status_data?from_date=${valvefromDate}&to_date=${valvetoDate}&type=${type};
    const apiValveUrl =  `${baseUrl}/api/gas/pfdb_valve_status_data?from_date=2024-12-01&to_date=${valvetoDate}&type=${type}`;
    console.log("API URL:", apiValveUrl);
  
    $.ajax({
      url: apiValveUrl,
      type: 'GET',
      headers: { "sessionId": "f72c970e-792b-40f7-954a-a82958d20cb5-57" },
      success: function (response) {
        console.log("Full API Response:", response);
  
        // Validate response structure
        if (!response || !response.dateList) {
          $('#response').text("Invalid response format or missing data.");
          console.log("Hello World");
          console.error("Invalid API response:", response);
          return;
        }

        const countMap = response.balanceAlertsCount;
  
        console.log(countMap);

        const dataValues = [
          parseInt(countMap.valveClosed),
          parseInt(countMap.valveAboutToClose),
          parseInt(countMap.notificationIssued),
          parseInt(countMap.positiveBalance)
      ];

      console.log(dataValues);

      const prepaidLabels = ['Valve Closed', 'About to Close', 'Notification Issued', 'Positive'];
      const prepaidColors = ['#f00', '#ff7600','#2563eb', '#18ae00'];
      renderPrepaidStatusChart(dataValues, prepaidLabels, "prepaid-chart", prepaidColors);
  
        // Populate table
        //populateTable(response.resources, type);
        
         if(type==="BALANCE_ALERTS_VALVE_CLOSED" || type==="BALANCE_ALERTS_ABOUT_TO_CLOSE" || type==="BALANCE_ALERTS_NOTIFICATION_ISSUED" || type==="BALANCE_ALERTS_POSITIVE") populateBalanceAlertsTable(response.dataMapList,type+"_1");
         
      },
      
      error: function (xhr, status, error) {
        console.error(`Error: ${error}, Status: ${status}, Response:`, xhr.responseText);
        $('#response').text("Failed to fetch data from the server.");
    }    
    });
  });

  function populateBalanceAlertsTable(resources,type) {
    // Get the table body element
    const tableBody = $('#' + type);

    console.log("Hello World !!!!" + type);
  
    // Clear any previous content in the table body
    tableBody.empty();
  
    // Loop through the data array and create rows
    resources.forEach((item, index) => {
      // Create a new table row
      const row = $('<tr></tr>');
  
      // Add cells to the row
      row.append('<td><input type="checkbox"></td>'); // Checkbox column
      row.append('<td>' + (index + 1) + '</td>'); // Serial Number
      row.append('<td>' + (item.appliance_serial_no || '-') + '</td>'); // LDN
      row.append('<td>' + (item.contract_ac_no || '-') + '</td>'); // BP No.
      row.append('<td>' + (item.unit_name || '-') + '</td>'); // Current Balance
      row.append('<td>' + (item.subscriber_no || '-') + '</td>'); // Current Balance
      row.append('<td>' + (item.appliance_name || '-') + '</td>'); // Current Balance
      row.append('<td>' + (item.closing_balance || '-') + '</td>'); // Current Balance
      row.append('<td>' + (item.last_update_time
        ? new Date(item.last_update_time).toLocaleString("en-GB", { 
            day: "2-digit", 
            month: "short", 
            year: "numeric", 
            hour: "2-digit", 
            minute: "2-digit", 
            second: "2-digit", 
            hour12: false 
        }) 
        : 'N/A') + '</td>');
  
      // Append the row to the table body
      tableBody.append(row);
    });
  }
  
  function populateAlarmsTable(resources,type){
    const tableBody = $('#' + type);
  
    console.log("Hello World====sssssstype---->"+type);
  
  // Clear any existing rows in the table body
    tableBody.empty();
  
  // Iterate over the resources and construct table rows
  resources.forEach((item, index) => {
  const row = $('<tr></tr>'); // Create a new row element
  
  // Add cells to the row
  row.append('<td><input type="checkbox"></td>'); // Checkbox column
  row.append('<td>' + (index + 1) + '</td>'); // Serial Number column
  row.append('<td>' + (item.LDN || 'N/A') + '</td>'); // LDN column
  row.append('<td>' + (item.BPNO || 'N/A') + '</td>'); // BP No. column
  row.append('<td>' + (item.unitName || 'N/A') + '</td>'); // Readings column
  row.append('<td>' + (item.subscriberName || 'N/A') + '</td>'); // Reason for Non-Communication column
  row.append('<td>' + (item.subscriberNo || 'N/A') + '</td>'); // LDN column
  row.append('<td>' + (item.eventCode || 'N/A') + '</td>'); // BP No. column
  row.append('<td>' + (item.eventTime
    ? new Date(item.eventTime).toLocaleString("en-GB", { 
        day: "2-digit", 
        month: "short", 
        year: "numeric", 
        hour: "2-digit", 
        minute: "2-digit", 
        second: "2-digit", 
        hour12: false 
    }) 
    : 'N/A') + '</td>');
  row.append('<td>' + (item.creationTime
    ? new Date(item.creationTime).toLocaleString("en-GB", { 
        day: "2-digit", 
        month: "short", 
        year: "numeric", 
        hour: "2-digit", 
        minute: "2-digit", 
        second: "2-digit", 
        hour12: false 
    }) 
    : 'N/A') + '</td>');
  row.append('<td>' + (item.reading || 'N/A') + '</td>'); // LDN column
  row.append('<td>' + (item.LDP
    ? new Date(item.LDP).toLocaleString("en-GB", { 
        day: "2-digit", 
        month: "short", 
        year: "numeric", 
        hour: "2-digit", 
        minute: "2-digit", 
        second: "2-digit", 
        hour12: false 
    }) 
    : 'N/A') + '</td>');

  
  // Append the row to the table body
  tableBody.append(row);
    });
  
      }
  
  function populateConsumptionTable(resources, type) {
    // Get the table body element by using the dataName (table id)
    const tableBody = $('#' + type );
    console.log("dataName====="+type);
    console.log("TableBody (HTML)----" + tableBody.html());
  
    // Clear any previous data in the table body
    tableBody.empty();
  
    // Loop through the resources and add rows to the table
    resources.forEach((item, index) => {
        const row = $(`
            <tr>
                <th scope="row"><input type="checkbox"></th>
                <td>${index + 1}</td> <!-- Serial number -->
                <td>${item.LDN}</td>
                <td>${item.BPNO}</td>
                <td>${item.subscriberName}</td>
                <td>${item.subscriberNo}</td>
                <td>${item.unitName}</td>
                <td>${item.reading}</td>
                <td>${item.currentBalance}</td>
                <td>${ new Date(item.LDP).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }) }</td>
                <td>${item.reason}</td>
                <td>
                  <div class="consump-date11">
                    <ul>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                      <li>100 m³</li>
                    </ul>
                  </div>
                </td>
            </tr>
        `);
  
        // Append the row to the table body
    tableBody.append(row);
    });
  }
  

  function renderPrepaidStatusChart(dataValues, prepaidLabels, elementId ,prepaidColors) {
    // Check if required parameters are provided
    if (!dataValues || !prepaidLabels || !elementId) {
      console.error("Missing required parameters: 'series', 'labels', or 'elementId'.");
      return;
    }
  
    // Default colors if none are provided
    const defaultColors = prepaidColors;
  
    // Chart options
    const options = {
      series: dataValues,
      chart: {
        type: 'donut',
      },
      labels: prepaidLabels,
      colors: prepaidColors, // Use provided colors or fallback to default
      responsive: [{
        breakpoint: 480,
        options: {
          chart: {
            // Adjust chart width here if needed
          },
          legend: {
            position: 'bottom'
          }
        }
      }]
    };
  
    // Render the chart
    const chart = new ApexCharts(document.querySelector(`#${elementId}`), options);
chart.render();

  }
  
  window.addEventListener('load', () => {
    console.log("Page loaded. Add any default chart or functionality here.");
  });
  
  function logout(){
    const logoutUrl = `${baseUrl}/ui/logout`;
    console.log("hello url = " + logoutUrl);
    window.location.href = logoutUrl; // Redirects to the logout URL
}

function navigateTo(endpoint) {
  const url = `${baseUrl}/ui/${endpoint}`;
  window.open(url, '_blank'); // Opens the URL in a new tab
}